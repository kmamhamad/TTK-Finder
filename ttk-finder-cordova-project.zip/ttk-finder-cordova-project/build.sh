#!/bin/bash

echo "==================================="
echo "  Building ${APP_NAME} APK"
echo "==================================="
echo ""

# Check if cordova is installed
if ! command -v cordova &> /dev/null; then
    echo "Installing Cordova..."
    npm install -g cordova
fi

# Check if platform exists, if not add it
if [ ! -d "platforms/android" ]; then
    echo "Adding Android platform..."
    cordova platform add android
fi

# Build the APK
echo "Building APK..."
cordova build android

if [ $? -eq 0 ]; then
    echo ""
    echo "==================================="
    echo "  Build Successful!"
    echo "==================================="
    echo ""
    echo "APK location:"
    echo "platforms/android/app/build/outputs/apk/debug/app-debug.apk"
    echo ""
else
    echo ""
    echo "Build failed. Please check the error messages above."
fi
