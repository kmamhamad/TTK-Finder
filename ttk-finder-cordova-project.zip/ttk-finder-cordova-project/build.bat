@echo off
echo ===================================
echo   Building %APP_NAME% APK
echo ===================================
echo.

REM Check if cordova is installed
where cordova >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Installing Cordova...
    npm install -g cordova
)

REM Check if platform exists
if not exist "platforms\android" (
    echo Adding Android platform...
    call cordova platform add android
)

REM Build the APK
echo Building APK...
call cordova build android

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ===================================
    echo   Build Successful!
    echo ===================================
    echo.
    echo APK location:
    echo platforms\android\app\build\outputs\apk\debug\app-debug.apk
    echo.
) else (
    echo.
    echo Build failed. Please check the error messages above.
)
pause
