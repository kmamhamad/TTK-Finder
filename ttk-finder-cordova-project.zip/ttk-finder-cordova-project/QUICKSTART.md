# Quick Start Guide

## Fastest Way to Build Your APK

### Option 1: Using the Build Script

**Linux/macOS:**
```bash
chmod +x build.sh
./build.sh
```

**Windows:**
```
build.bat
```

### Option 2: Manual Build

1. Install dependencies:
   ```bash
   npm install
   ```

2. Add Android platform:
   ```bash
   cordova platform add android
   ```

3. Build the APK:
   ```bash
   cordova build android
   ```

### APK Location

After building, your APK will be at:
```
platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

## Installing on Your Phone

1. Transfer the APK to your phone
2. Enable "Install from unknown sources" in settings
3. Open the APK file to install

## Need Help?

Check the README.md file for detailed instructions.
