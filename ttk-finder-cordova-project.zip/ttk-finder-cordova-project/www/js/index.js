// Cordova app initialization
document.addEventListener('deviceready', function() {
    console.log('Device is ready!');
    // Your app initialization code here
}, false);

// Handle back button on Android
document.addEventListener('backbutton', function(event) {
    event.preventDefault();
    // Add your back button logic here
    // navigator.app.exitApp(); // Uncomment to exit app on back press
}, false);
