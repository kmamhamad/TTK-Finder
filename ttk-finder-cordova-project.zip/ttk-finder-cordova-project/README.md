# TTK Finder

A Cordova-based Android application.

## Prerequisites

Before building this app, make sure you have the following installed:

- **Node.js** (v16 or later) - [Download here](https://nodejs.org/)
- **Java JDK 11** or later - [Download here](https://adoptium.net/)
- **Android Studio** with Android SDK - [Download here](https://developer.android.com/studio)
- **Gradle** (usually comes with Android Studio)

### Environment Variables

Make sure these environment variables are set:

```bash
# Linux/macOS
export JAVA_HOME=/path/to/jdk
export ANDROID_HOME=/path/to/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/emulator
export PATH=$PATH:$ANDROID_HOME/platform-tools
export PATH=$PATH:$ANDROID_HOME/tools
export PATH=$PATH:$ANDROID_HOME/tools/bin

# Windows (PowerShell)
$env:JAVA_HOME = "C:\Program Files\Java\jdk-11"
$env:ANDROID_HOME = "C:\Users\YourName\AppData\Local\Android\Sdk"
```

## Installation

1. Navigate to the project directory:
   ```bash
   cd ttk-finder-cordova-project
   ```

2. Install Cordova globally (if not already installed):
   ```bash
   npm install -g cordova
   ```

3. Add Android platform:
   ```bash
   cordova platform add android
   ```

## Building the APK

### Debug APK
```bash
cordova build android
```

The APK will be generated at:
`platforms/android/app/build/outputs/apk/debug/app-debug.apk`

### Release APK (Signed)
```bash
cordova build android --release
```

For release builds, you'll need to sign your APK. See [Cordova documentation](https://cordova.apache.org/docs/en/latest/guide/platforms/android/#signing-an-app) for details.

## Running the App

### On an Emulator
1. Create an Android Virtual Device (AVD) in Android Studio
2. Run:
   ```bash
   cordova run android --emulator
   ```

### On a Physical Device
1. Enable USB Debugging on your Android device
2. Connect your device via USB
3. Run:
   ```bash
   cordova run android --device
   ```

## Project Structure

```
├── www/                  # Web assets (HTML, CSS, JS)
│   ├── index.html        # Main HTML file
│   ├── css/              # Stylesheets
│   ├── js/               # JavaScript files
│   └── img/              # Images
├── config.xml            # Cordova configuration
├── package.json          # NPM package file
└── README.md             # This file
```

## Customization

- **Edit HTML**: Modify `www/index.html` to change the app content
- **Add CSS**: Add stylesheets to `www/css/`
- **Add JavaScript**: Add scripts to `www/js/`
- **Change Config**: Edit `config.xml` for app settings

## Troubleshooting

### Common Issues

1. **"Could not find gradle"**
   - Install Gradle or use the wrapper included in Android Studio

2. **"Failed to find 'ANDROID_HOME'"**
   - Make sure ANDROID_HOME environment variable is set correctly

3. **"Could not find target with hash string 'android-XX'"**
   - Install the required Android SDK version via Android Studio SDK Manager

4. **Build fails with Java errors**
   - Make sure JAVA_HOME points to JDK 11 or later
   - Check that your Java version is compatible

## Resources

- [Cordova Documentation](https://cordova.apache.org/docs/en/latest/)
- [Cordova Android Platform Guide](https://cordova.apache.org/docs/en/latest/guide/platforms/android/)
- [Android Developer Documentation](https://developer.android.com/docs)

## License

MIT License

## Author

Kurd0
